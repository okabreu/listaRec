create database exercicios;
use exercicios;

-- exercicio (1)
create table tipoConta(
	id bigint not null auto_increment,
    tipoConta enum('PREMIUM','FREE'),
    permissoes varchar(500) not null,
    dataAssinatura date,
    dataVencimento date,
    primary key(id)
);

create table usuario(
	id bigint not null auto_increment,
    nome varchar(100) not null,
    cpf varchar(12) not null,
    dataNasc date not null,
    email varchar(150) not null,
    tipoContaFK bigint not null,
    foreign key(tipoContaFK) references tipoConta(id),
    primary key(id)
);

-- exercicio (2)
create table cliente(
	idCLIENTE bigint not null auto_increment,
    nomeCLIENTE varchar(30) not null,
    RG_CLIENTE varchar(20) not null,
    primary key(idCLIENTE)
);

create table vendedor(
	idVENDEDOR bigint not null auto_increment,
    nomeVENDEDOR varchar(45) not null,
    primary key(idVENDEDOR)
);

create table pedido(
	numPEDIDO bigint not null auto_increment,
    DataPedido datetime not null,
    ValorPedido numeric(10,2) not null,
    VendedorFK bigint not null,
    ClienteFK bigint not null,
    foreign key(VendedorFK) references vendedor(idVENDEDOR),
    foreign key(ClienteFK) references cliente(idCLIENTE),
    primary key(numPEDIDO)
);

-- exercicio (3)
create table fornecedor(
	idFORNECEDOR bigint not null auto_increment,
    nomeForncedor varchar(45) not null,
    primary key(idFORNECEDOR)
);

create table principioAtivo(
	idPRINCIPIOATIVO bigint not null auto_increment,
    nomePrincipioAtivo varchar(60) not null,
    primary key(idPRINCIPIOATIVO)
);

create table medicamento(
	idMEDICAMENTO bigint not null auto_increment,
    nomeComercial varchar(60) not null,
    principioAtivoFK bigint not null,
    fonecedorFK bigint not null,
    qtdEstoque bigint not null,
    foreign key(principioAtivoFK) references principioAtivo(idPRINCIPIOATIVO),
    foreign key(fonecedorFK) references fornecedor(idFORNECEDOR),
    primary key(idMEDICAMENTO)
);

-- exercicio (4)
