create database curso;
use curso;

create table curso(
	id bigint not null auto_increment,
    nomeCurso varchar(200) not null,
    identificacaoTipo enum('bacharelado','tecnólogo','licenciatura') not null,
    primary key(id)
);

create table disciplinas(
	codigo bigint not null auto_increment,
    nomeDisciplina varchar(200) not null,
    carga numeric(10,2) not null,
    cursoFK bigint not null,
    foreign key(cursoFK) references curso(id),
    primary key(codigo)
);

create table aluno(
	id bigint not null auto_increment,
    nomeAluno varchar(100) not null,
    dataNasc datetime not null,
    email varchar(100) not null,
    telefone varchar(12) not null,
    numeroMatricula varchar(5) not null,
    cursoFK bigint not null,
    disciplinasFK bigint not null,
    foreign key(cursoFK) references curso(id),
    foreign key(disciplinasFK) references disciplinas(codigo),
    primary key(id)
);