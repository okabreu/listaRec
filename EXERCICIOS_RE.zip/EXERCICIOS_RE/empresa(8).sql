create database empresa;
use empresa;

create table cargo(
	id bigint not null auto_increment,
    nomeCargo bigint not null,
    primary key(id)
);

create table departamento(
	id bigint not null auto_increment,
    nomeDepartamento bigint not null,
    primary key(id)
);

create table funcionario(
	id bigint not null auto_increment,
    nomeFuncionario varchar(100) not null,
    dataNasc datetime not null,
    CPF varchar(13) not null,
    salarioAtual numeric(10,2) not null,
    cargoFK bigint not null,
    departamentoFK bigint not null,
    foreign key(cargoFK) references cargo(id),
    foreign key(departamentoFK) references departamento(id),
    primary key(id)
);

create table clientes(
	id bigint not null auto_increment,
    nomeCompleto varchar(100) not null,
    CNPJ varchar(13) not null,
    primary key(id)
);

create table projetos(
	id bigint not null auto_increment,
    nomeProjeto varchar(150) not null,
    dataInicio datetime not null,
    dataFim datetime not null,
    funcionarioFK bigint not null,
    clienteFK bigint not null,
    foreign key(funcionarioFK) references funcionario(id),
    foreign key(clienteFK) references clientes(id),
    primary key(id)
);