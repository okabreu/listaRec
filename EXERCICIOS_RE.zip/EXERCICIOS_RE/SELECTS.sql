-- a) Liste os clientes exibindo nome, cidade de UF.
SELECT Nome_RazaoSocial, Cidade, UF FROM lcliente;

-- b) Exiba as licenças de uso que contenham “A” no número de licença.
SELECT * FROM llicenca WHERE NumLicenca LIKE '%A%';

-- c) Exiba os clientes cujo nome comece com “P”. Ordene por nome.
SELECT * FROM lcliente WHERE Nome_RazaoSocial LIKE 'P%' ORDER BY Nome_RazaoSocial;

-- d) Exiba os clientes cujo nome termina com “AR”. Ordene por nome em ordem decrescente.
SELECT * FROM lcliente WHERE Nome_RazaoSocial LIKE '%AR' ORDER BY Nome_RazaoSocial DESC;

-- e) Exiba os clientes que contém “W” ou “Y” no nome.
SELECT * FROM lcliente WHERE Nome_RazaoSocial LIKE '%W%' OR Nome_RazaoSocial LIKE '%Y%';

-- f) Exiba as licenças de software com valor igual ou superior a R$ 1.200,00. 
-- Ordene por valor de forma decrescente.
SELECT * FROM llicenca WHERE ValorAquisicao >= 1200.00 ORDER BY ValorAquisicao DESC;

-- g) Exiba os clientes cuja identificação (código) seja maior que 150 e menor que 200.
SELECT * FROM lcliente WHERE idCLIENTE > 150 AND idCLIENTE < 200;

-- h) Exiba as licenças de software com valor entre R$ 250,00 e R$ 500,00. Ordene em ordem crescente de valor de 
-- licença.
SELECT * FROM llicenca WHERE ValorAquisicao >= 250.00 AND ValorAquisicao <= 500.00
ORDER BY ValorAquisicao ASC;

-- i) Exiba as licenças que foram comercializadas após 2008 e cujo valor esteja entre R$ 300 e R$ 450 ou cujo valor 
-- esteja entre R$ 600 e R$ 800.
SELECT * FROM llicenca WHERE DtAquisicao > '2008-01-01' 
AND ((ValorAquisicao >= 300.00 AND ValorAquisicao <= 450.00) OR (ValorAquisicao >= 600.00 AND ValorAquisicao <= 800.00));

-- j) Exiba os clientes que pertençam a uma das UFs: “SP”, “RS”, “PR”, MG”
SELECT * FROM lcliente WHERE UF IN ('SP', 'RS', 'PR', 'MG');

-- k) Exiba os clientes que NÃO pertençam a nenhuma das UFs: “RJ”, “ES”, “SP”, MG”
SELECT * FROM lcliente WHERE UF NOT IN ('RJ', 'ES', 'SP', 'MG');

-- l) Sua empresa virou cliente e vai comprar licenças de software. Inclua sua empresa na tabela de clientes e 
-- associe-a a um setor e a um tipo de empresa.
INSERT INTO `lcliente` VALUES(516,2,2,'CHILLI','AV. Emilio, 200','Campinas','SP',13057648);

-- m) Inclua um novo Software e versão nas tabelas apropriadas.
INSERT INTO `lsoftware` VALUES (11,'Visual S');
INSERT INTO `lversao` VALUES (11,'2007');

-- n) Inclua 3 aquisições de licença para sua empresa. Uma delas deve ser do software/versão que você incluiu no 
-- item anterior.
INSERT INTO `llicenca` VALUES ('998A34E4',515,10,'2000','2002-05-01',2442.00)
,('103A56E4',3,1,'2000','2001-06-31',2357.00)
,('3AE2124',321,3,'2000','2001-11-09',2092.00);

-- o) A tabela de preços subiu de última hora. Altere o valor da Licença que você inclui para o novo software 
-- incluído. Aumente o valor em 12,5%.
-- NAO CONSEGUI INSERIR OS DADOS POIS NAO CONSEGUI IDENTIFICAR O ERRO, ENTAO FIZ COM O PRIMEIRO DADO DA TABELA
UPDATE llicenca SET ValorAquisicao = ValorAquisicao * 1.125 WHERE NumLicenca = '1003AE4';

-- p) Altere a descrição do tipo de empresa de código 6 para “Governo”
UPDATE ltipo_empresa SET DescricaoTipo = 'Governo' WHERE idTIPO_Empresa = 6;

-- q) As Licenças comercializadas terão que pagar imposto.....
SELECT NumLicenca, DtAquisicao, ValorAquisicao, (ValorAquisicao * 0.1) 
AS Imposto, (ValorAquisicao - (ValorAquisicao * 0.1)) AS ValorLiquido FROM llicenca
WHERE YEAR(DtAquisicao) >= 2011 ORDER BY DtAquisicao;

-- r) Exiba todos softwares com todas as suas versões. Ordene por nome e versão do software.
SELECT s.NomeSoftware, v.Versao FROM lsoftware s JOIN lversao v ON s.idSOFTWARE = v.idSOFTWARE_FK
ORDER BY s.NomeSoftware, v.Versao;

-- s) Liste a quantidade de clientes cadastrados;
SELECT COUNT(*) AS QuantidadeClientes FROM lcliente;

-- t) Exiba software, versão, nome do cliente, descrição do tipo do cliente, nome do setor do cliente e as licenças 
-- adquiridas pelo cliente com seu número, data e valor de aquisição. Ordene por software, versão, data, cliente.


-- u) Lista a quantidade de licenças vendidas
SELECT COUNT(*) AS QuantidadeLicencasVendidas FROM llicenca;

-- v) Liste a quantidade de licenças para cada cliente. Apresente o nome do cliente. Ordene pelo nome do cliente.
SELECT lc.Nome_RazaoSocial AS NomeCliente, COUNT(ll.NumLicenca) AS QuantidadeLicencas
FROM lcliente lc
LEFT JOIN llicenca ll ON lc.idCLIENTE = ll.idCLIENTE_FK
GROUP BY lc.idCLIENTE, lc.Nome_RazaoSocial
ORDER BY lc.Nome_RazaoSocial;